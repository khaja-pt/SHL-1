﻿namespace SHL_Platform.Models
{
    public class Survey
    {
        public int Id { get; set; }
        public string FormDataJson { get; set; } // Serialized form data
    }

}
